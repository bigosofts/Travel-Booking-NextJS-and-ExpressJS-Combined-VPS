import React from 'react';

function Input(props) {
    return (
        <div>
            
        </div>
    );
}

export default Input;