import DashboardMetrics from "@/components/dashboardMetrics/DashboardMetrics";

function page(props) {
    return (
        <DashboardMetrics/> 
    );
}

export default page;