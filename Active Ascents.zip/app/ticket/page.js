import Ticket from "@/components/ticket/Ticket";

const page = () => {
  return <Ticket />;
};

export default page;
